<#
  FX Portal helper (Windows).

  Does what a Premiere panel can't do on its own:
    - global hotkey (only while Premiere is the active app)
    - bring the FX Portal window to the front
    - read/write clipboard formats (presets, images)
    - send keyboard shortcuts to Premiere

  Run modes:
    -Serve            long-running service for the panel: one JSON command per
                      line on stdin, one JSON reply/event per line on stdout
    -DumpClipboard    diagnostics: save every clipboard format to -Out folder
#>
param(
  [switch]$Serve,
  [switch]$DumpClipboard,
  [string]$Out = "$env:TEMP\fxportal-clipboard"
)

$ErrorActionPreference = "Stop"
# UTF-8 both ways so paths with Bangla or other non-English characters survive.
$utf8 = New-Object System.Text.UTF8Encoding($false)
[Console]::OutputEncoding = $utf8
[Console]::InputEncoding = $utf8
Add-Type -AssemblyName System.Windows.Forms
Add-Type -AssemblyName System.Drawing

$source = @"
using System;
using System.IO;
using System.Text;
using System.Threading;
using System.Diagnostics;
using System.Collections.Generic;
using System.Runtime.InteropServices;

public static class FxNative {
  // ---------------- Win32 ----------------
  [DllImport("user32.dll", SetLastError=true)] static extern bool OpenClipboard(IntPtr h);
  [DllImport("user32.dll")] static extern bool CloseClipboard();
  [DllImport("user32.dll")] static extern uint EnumClipboardFormats(uint f);
  [DllImport("user32.dll", CharSet=CharSet.Unicode)] static extern int GetClipboardFormatName(uint f, StringBuilder sb, int max);
  [DllImport("user32.dll")] static extern IntPtr GetClipboardData(uint f);
  [DllImport("kernel32.dll")] static extern IntPtr GlobalLock(IntPtr h);
  [DllImport("kernel32.dll")] static extern bool GlobalUnlock(IntPtr h);
  [DllImport("kernel32.dll")] static extern UIntPtr GlobalSize(IntPtr h);

  [DllImport("user32.dll")] static extern IntPtr GetForegroundWindow();
  [DllImport("user32.dll")] static extern bool SetForegroundWindow(IntPtr h);
  [DllImport("user32.dll")] static extern IntPtr SetFocus(IntPtr h);
  [DllImport("user32.dll")] static extern bool BringWindowToTop(IntPtr h);
  [DllImport("user32.dll")] static extern bool ShowWindow(IntPtr h, int cmd);
  [DllImport("user32.dll")] static extern bool IsWindowVisible(IntPtr h);
  [DllImport("user32.dll")] static extern bool IsIconic(IntPtr h);
  [DllImport("user32.dll")] static extern uint GetWindowThreadProcessId(IntPtr h, out uint pid);
  [DllImport("kernel32.dll")] static extern uint GetCurrentThreadId();
  [DllImport("user32.dll")] static extern bool AttachThreadInput(uint a, uint b, bool attach);
  [DllImport("user32.dll", CharSet=CharSet.Unicode)] static extern int GetWindowText(IntPtr h, StringBuilder sb, int max);
  [DllImport("user32.dll", CharSet=CharSet.Unicode)] static extern int GetClassName(IntPtr h, StringBuilder sb, int max);
  delegate bool EnumWindowsProc(IntPtr h, IntPtr p);
  [DllImport("user32.dll")] static extern bool EnumWindows(EnumWindowsProc cb, IntPtr p);

  [StructLayout(LayoutKind.Sequential)] struct KEYBDINPUT { public ushort wVk; public ushort wScan; public uint dwFlags; public uint time; public IntPtr dwExtraInfo; }
  [StructLayout(LayoutKind.Sequential)] struct MOUSEINPUT { public int dx; public int dy; public uint mouseData; public uint dwFlags; public uint time; public IntPtr dwExtraInfo; }
  [StructLayout(LayoutKind.Explicit)] struct INPUTUNION { [FieldOffset(0)] public MOUSEINPUT mi; [FieldOffset(0)] public KEYBDINPUT ki; }
  [StructLayout(LayoutKind.Sequential)] struct INPUT { public uint type; public INPUTUNION u; }
  [DllImport("user32.dll", SetLastError=true)] static extern uint SendInput(uint n, INPUT[] inputs, int size);
  [DllImport("user32.dll")] static extern short GetAsyncKeyState(int vk);

  const uint KEYEVENTF_KEYUP = 0x0002;
  const uint KEYEVENTF_EXTENDEDKEY = 0x0001;
  static readonly IntPtr FX_MARK = new IntPtr(0x46585054); // tags our own synthetic keys

  // ---------------- Output (thread-safe JSON lines) ----------------
  static readonly object outLock = new object();
  public static void Emit(string json) {
    lock (outLock) { Console.Out.WriteLine(json); Console.Out.Flush(); }
  }

  // ---------------- Clipboard diagnostics ----------------
  static string FormatName(uint f) {
    switch (f) {
      case 1: return "CF_TEXT"; case 2: return "CF_BITMAP"; case 7: return "CF_OEMTEXT";
      case 8: return "CF_DIB"; case 13: return "CF_UNICODETEXT"; case 15: return "CF_HDROP";
      case 16: return "CF_LOCALE"; case 17: return "CF_DIBV5";
    }
    StringBuilder sb = new StringBuilder(256);
    return GetClipboardFormatName(f, sb, 256) > 0 ? sb.ToString() : ("format_" + f);
  }

  static bool Open() {
    for (int i = 0; i < 20; i++) { if (OpenClipboard(IntPtr.Zero)) return true; Thread.Sleep(25); }
    return false;
  }

  /// Saves every clipboard format to <dir> and returns a text summary.
  public static string DumpClipboard(string dir) {
    Directory.CreateDirectory(dir);
    if (!Open()) throw new Exception("Clipboard is busy.");
    StringBuilder report = new StringBuilder();
    try {
      uint f = 0; int n = 0;
      while ((f = EnumClipboardFormats(f)) != 0) {
        n++;
        string name = FormatName(f);
        if (f == 2) { report.AppendLine(n + ". " + name + " (bitmap handle, skipped)"); continue; }
        IntPtr h = GetClipboardData(f);
        if (h == IntPtr.Zero) { report.AppendLine(n + ". " + name + " (no data)"); continue; }
        IntPtr p = GlobalLock(h);
        if (p == IntPtr.Zero) { report.AppendLine(n + ". " + name + " (not memory)"); continue; }
        try {
          int size = (int)GlobalSize(h).ToUInt32();
          byte[] bytes = new byte[size];
          Marshal.Copy(p, bytes, 0, size);
          string safe = System.Text.RegularExpressions.Regex.Replace(name, "[^A-Za-z0-9._-]", "_");
          File.WriteAllBytes(Path.Combine(dir, n.ToString("00") + "_" + safe + ".bin"), bytes);
          report.AppendLine(n + ". " + name + " id=" + f + " bytes=" + size);
        } finally { GlobalUnlock(h); }
      }
      if (n == 0) report.AppendLine("(clipboard is empty)");
    } finally { CloseClipboard(); }
    File.WriteAllText(Path.Combine(dir, "_summary.txt"), report.ToString());
    return report.ToString();
  }

  // ---------------- Windows & focus ----------------
  static string ProcessNameOf(IntPtr hwnd) {
    uint pid; GetWindowThreadProcessId(hwnd, out pid);
    try { return Process.GetProcessById((int)pid).ProcessName; } catch { return ""; }
  }

  /// True when the active window belongs to Premiere or to an FX Portal window.
  public static bool PremiereInFront() {
    string name = ProcessNameOf(GetForegroundWindow());
    return name.IndexOf("Premiere", StringComparison.OrdinalIgnoreCase) >= 0
        || name.IndexOf("CEPHtmlEngine", StringComparison.OrdinalIgnoreCase) >= 0;
  }

  public static IntPtr PremiereWindow() {
    foreach (Process p in Process.GetProcesses()) {
      try {
        if (p.ProcessName.IndexOf("Premiere", StringComparison.OrdinalIgnoreCase) >= 0 && p.MainWindowHandle != IntPtr.Zero)
          return p.MainWindowHandle;
      } catch {}
    }
    return IntPtr.Zero;
  }

  public static IntPtr FindWindowByTitle(string title) {
    IntPtr found = IntPtr.Zero;
    EnumWindows(delegate(IntPtr h, IntPtr p) {
      if (!IsWindowVisible(h)) return true;
      StringBuilder sb = new StringBuilder(256);
      GetWindowText(h, sb, 256);
      if (String.Equals(sb.ToString(), title, StringComparison.OrdinalIgnoreCase)) { found = h; return false; }
      return true;
    }, IntPtr.Zero);
    return found;
  }

  /// Brings a window to the front even when Windows' focus-stealing guard is on.
  public static bool Activate(IntPtr hwnd) {
    if (hwnd == IntPtr.Zero) return false;
    if (IsIconic(hwnd)) ShowWindow(hwnd, 9);
    uint pid;
    uint target = GetWindowThreadProcessId(hwnd, out pid);
    uint fg = GetWindowThreadProcessId(GetForegroundWindow(), out pid);
    uint me = GetCurrentThreadId();
    AttachThreadInput(me, fg, true);
    AttachThreadInput(me, target, true);
    try {
      // A tagged Alt tap unlocks SetForegroundWindow; the hook ignores it.
      INPUT[] alt = new INPUT[] { Key(0x12, false), Key(0x12, true) };
      SendInput(2, alt, Marshal.SizeOf(typeof(INPUT)));
      BringWindowToTop(hwnd);
      SetForegroundWindow(hwnd);
      SetFocus(hwnd);
    } finally {
      AttachThreadInput(me, target, false);
      AttachThreadInput(me, fg, false);
    }
    return GetForegroundWindow() == hwnd;
  }

  public static bool FocusPremiere() { return Activate(PremiereWindow()); }

  public static bool FocusWindow(string title) { return Activate(FindWindowByTitle(title)); }

  public static string ForegroundInfo() {
    IntPtr h = GetForegroundWindow();
    StringBuilder t = new StringBuilder(256), c = new StringBuilder(256);
    GetWindowText(h, t, 256); GetClassName(h, c, 256);
    return t.ToString() + " [" + c.ToString() + "] (" + ProcessNameOf(h) + ")";
  }

  // ---------------- Floating palette window ----------------
  // FX Portal's search window is a normal Premiere (CEP) window. These calls turn
  // it into a borderless floating bar: no title bar, see-through around the bar,
  // centred over Premiere, hidden (not closed) when dismissed.
  [StructLayout(LayoutKind.Sequential)] public struct RECT { public int Left, Top, Right, Bottom; }
  [DllImport("user32.dll")] static extern bool GetWindowRect(IntPtr h, out RECT r);
  [DllImport("user32.dll", EntryPoint="GetWindowLongPtrW")] static extern IntPtr GetWindowLongPtr(IntPtr h, int i);
  [DllImport("user32.dll", EntryPoint="SetWindowLongPtrW")] static extern IntPtr SetWindowLongPtr(IntPtr h, int i, IntPtr v);
  [DllImport("user32.dll")] static extern bool SetLayeredWindowAttributes(IntPtr h, uint key, byte alpha, uint flags);
  [DllImport("user32.dll")] static extern bool SetWindowPos(IntPtr h, IntPtr after, int x, int y, int w, int hgt, uint flags);
  [DllImport("user32.dll")] static extern uint GetDpiForWindow(IntPtr h);
  [DllImport("user32.dll")] static extern bool SetProcessDPIAware();
  [DllImport("dwmapi.dll")] static extern int DwmSetWindowAttribute(IntPtr h, int attr, ref int value, int size);
  [DllImport("user32.dll")] static extern IntPtr MonitorFromWindow(IntPtr h, uint flags);
  [StructLayout(LayoutKind.Sequential)] struct MONITORINFO { public int cbSize; public RECT rcMonitor; public RECT rcWork; public uint dwFlags; }
  [DllImport("user32.dll")] static extern bool GetMonitorInfo(IntPtr m, ref MONITORINFO mi);

  const int GWL_STYLE = -16, GWL_EXSTYLE = -20;
  const long WS_CAPTION = 0x00C00000L, WS_THICKFRAME = 0x00040000L, WS_SYSMENU = 0x00080000L,
             WS_MINIMIZEBOX = 0x00020000L, WS_MAXIMIZEBOX = 0x00010000L, WS_BORDER = 0x00800000L, WS_DLGFRAME = 0x00400000L;
  const long WS_EX_LAYERED = 0x00080000L, WS_EX_TOOLWINDOW = 0x00000080L, WS_EX_APPWINDOW = 0x00040000L,
             WS_EX_WINDOWEDGE = 0x00000100L, WS_EX_CLIENTEDGE = 0x00000200L, WS_EX_DLGMODALFRAME = 0x00000001L;
  const uint SWP_NOSIZE = 0x1, SWP_NOMOVE = 0x2, SWP_NOZORDER = 0x4, SWP_NOACTIVATE = 0x10, SWP_FRAMECHANGED = 0x20, SWP_SHOWWINDOW = 0x40;
  /// Pixels of exactly this colour (#010101) become see-through and click-through.
  public const uint KEY_COLOR = 0x00010101;

  static bool dpiSet = false;
  public static void DpiAware() { if (!dpiSet) { try { SetProcessDPIAware(); } catch {} dpiSet = true; } }

  /// Finds a top-level window by exact title, visible or hidden, owned by Premiere or CEP.
  public static IntPtr FindAnyWindow(string title) {
    IntPtr found = IntPtr.Zero;
    EnumWindows(delegate(IntPtr h, IntPtr p) {
      StringBuilder sb = new StringBuilder(256);
      GetWindowText(h, sb, 256);
      if (!String.Equals(sb.ToString(), title, StringComparison.Ordinal)) return true;
      string proc = ProcessNameOf(h);
      if (proc.IndexOf("Premiere", StringComparison.OrdinalIgnoreCase) < 0 && proc.IndexOf("CEPHtmlEngine", StringComparison.OrdinalIgnoreCase) < 0) return true;
      found = h; return false;
    }, IntPtr.Zero);
    return found;
  }

  static void MakeBorderless(IntPtr h) {
    long style = GetWindowLongPtr(h, GWL_STYLE).ToInt64();
    long want = style & ~(WS_CAPTION | WS_THICKFRAME | WS_SYSMENU | WS_MINIMIZEBOX | WS_MAXIMIZEBOX | WS_BORDER | WS_DLGFRAME);
    long ex = GetWindowLongPtr(h, GWL_EXSTYLE).ToInt64();
    long wantEx = (ex | WS_EX_LAYERED | WS_EX_TOOLWINDOW) & ~(WS_EX_APPWINDOW | WS_EX_WINDOWEDGE | WS_EX_CLIENTEDGE | WS_EX_DLGMODALFRAME);
    if (style != want) SetWindowLongPtr(h, GWL_STYLE, new IntPtr(want));
    if (ex != wantEx) SetWindowLongPtr(h, GWL_EXSTYLE, new IntPtr(wantEx));
    SetLayeredWindowAttributes(h, KEY_COLOR, 255, 0x1); // LWA_COLORKEY
    int square = 1; // Windows 11: no rounded system corners; the bar draws its own.
    try { DwmSetWindowAttribute(h, 33, ref square, 4); } catch {}
  }

  static double Scale(IntPtr h) {
    try { uint d = GetDpiForWindow(h); if (d > 0) return d / 96.0; } catch {}
    return 1.0;
  }

  public static bool IsShownAndFront(string title) {
    IntPtr h = FindAnyWindow(title);
    return h != IntPtr.Zero && IsWindowVisible(h) && GetForegroundWindow() == h;
  }

  [StructLayout(LayoutKind.Sequential)] public struct POINT { public int X, Y; }
  [DllImport("user32.dll")] static extern bool GetCursorPos(out POINT p);
  [DllImport("user32.dll")] static extern IntPtr MonitorFromPoint(POINT p, uint flags);

  static RECT WorkAreaOf(IntPtr monitor) {
    MONITORINFO mi = new MONITORINFO(); mi.cbSize = Marshal.SizeOf(typeof(MONITORINFO));
    GetMonitorInfo(monitor, ref mi); return mi.rcWork;
  }

  /// Shows the palette borderless. With a saved spot (x, y in screen pixels) it goes
  /// there; otherwise the bar sits in the exact middle of Premiere's screen.
  /// barCenterCss = distance from the window top to the middle of the bar (CSS px).
  public static string PaletteShow(string title, int cssW, int cssH, int x, int y, bool hasPos, int barCenterCss) {
    DpiAware();
    IntPtr h = FindAnyWindow(title);
    if (h == IntPtr.Zero) return "missing";
    MakeBorderless(h);
    double s = Scale(h);
    int w = (int)Math.Round(cssW * s), hh = (int)Math.Round(cssH * s);
    if (hasPos) {
      POINT p; p.X = x + w / 2; p.Y = y + 10;
      if (MonitorFromPoint(p, 0) == IntPtr.Zero) hasPos = false; // that screen is gone
    }
    if (!hasPos) {
      IntPtr main = PremiereWindow();
      RECT wa = WorkAreaOf(MonitorFromWindow(main != IntPtr.Zero ? main : h, 2));
      x = wa.Left + ((wa.Right - wa.Left) - w) / 2;
      y = wa.Top + (wa.Bottom - wa.Top) / 2 - (int)Math.Round(barCenterCss * s);
    }
    SetWindowPos(h, IntPtr.Zero, x, y, w, hh, SWP_FRAMECHANGED | SWP_SHOWWINDOW);
    Activate(h);
    return "shown";
  }

  /// Moves the window with the mouse while the left button is held. Returns "x,y".
  public static string PaletteDrag(string title) {
    DpiAware();
    IntPtr h = FindAnyWindow(title);
    if (h == IntPtr.Zero) return "";
    RECT r; GetWindowRect(h, out r);
    POINT start; GetCursorPos(out start);
    int x = r.Left, y = r.Top;
    DateTime limit = DateTime.Now.AddSeconds(30);
    while ((GetAsyncKeyState(0x01) & 0x8000) != 0 && DateTime.Now < limit) {
      POINT c; GetCursorPos(out c);
      int nx = r.Left + (c.X - start.X), ny = r.Top + (c.Y - start.Y);
      if (nx != x || ny != y) {
        x = nx; y = ny;
        SetWindowPos(h, IntPtr.Zero, x, y, 0, 0, SWP_NOSIZE | SWP_NOZORDER | SWP_NOACTIVATE);
      }
      Thread.Sleep(7);
    }
    return x + "," + y;
  }

  /// Changes only the height (the results list grows and shrinks).
  public static bool PaletteResize(string title, int cssH) {
    DpiAware();
    IntPtr h = FindAnyWindow(title);
    if (h == IntPtr.Zero) return false;
    RECT r; GetWindowRect(h, out r);
    int hh = (int)Math.Round(cssH * Scale(h));
    if (hh == r.Bottom - r.Top) return true;
    return SetWindowPos(h, IntPtr.Zero, 0, 0, r.Right - r.Left, hh, SWP_NOMOVE | SWP_NOZORDER | SWP_NOACTIVATE);
  }

  /// Hides the palette and gives focus back to Premiere.
  public static bool PaletteHide(string title) {
    IntPtr h = FindAnyWindow(title);
    if (h != IntPtr.Zero) ShowWindow(h, 0); // SW_HIDE
    FocusPremiere();
    return h != IntPtr.Zero;
  }

  // ---------------- Silent Paste Attributes ----------------
  // Preset apply runs Premiere's Paste Attributes. A window-event watcher makes
  // the dialog invisible the moment it is created, then it is confirmed with Enter.
  delegate void WinEventProc(IntPtr hook, uint ev, IntPtr hwnd, int idObject, int idChild, uint thread, uint time);
  [DllImport("user32.dll")] static extern IntPtr SetWinEventHook(uint min, uint max, IntPtr mod, WinEventProc proc, uint pid, uint tid, uint flags);
  [DllImport("user32.dll")] static extern IntPtr GetAncestor(IntPtr h, uint flags);
  [DllImport("user32.dll")] static extern bool IsWindow(IntPtr h);

  static WinEventProc winEventProc; // kept alive for the GC
  static volatile bool pasteArmed = false;
  static IntPtr pasteDialog = IntPtr.Zero;
  static Thread watcher;

  static void EnsureWatcher() {
    if (watcher != null) return;
    watcher = new Thread(delegate() {
      winEventProc = new WinEventProc(OnWinEvent);
      SetWinEventHook(0x8000, 0x8002, IntPtr.Zero, winEventProc, 0, 0, 0x0002); // CREATE..SHOW, out of context, skip own process
      MSG msg;
      while (GetMessage(out msg, IntPtr.Zero, 0, 0) > 0) {}
    });
    watcher.IsBackground = true;
    watcher.Start();
    Thread.Sleep(50);
  }

  static void OnWinEvent(IntPtr hook, uint ev, IntPtr hwnd, int idObject, int idChild, uint thread, uint time) {
    if (!pasteArmed || idObject != 0 || hwnd == IntPtr.Zero) return;
    if (GetAncestor(hwnd, 2) != hwnd) return; // top-level windows only
    if (ProcessNameOf(hwnd).IndexOf("Premiere", StringComparison.OrdinalIgnoreCase) < 0) return;
    StringBuilder sb = new StringBuilder(256); GetWindowText(hwnd, sb, 256);
    string t = sb.ToString();
    if (t == "FX Portal" || t.StartsWith("Adobe Premiere")) return;
    long ex = GetWindowLongPtr(hwnd, GWL_EXSTYLE).ToInt64();
    SetWindowLongPtr(hwnd, GWL_EXSTYLE, new IntPtr(ex | WS_EX_LAYERED));
    SetLayeredWindowAttributes(hwnd, 0, 0, 0x2); // LWA_ALPHA = fully transparent
    if (t.Length > 0 && (ev == 0x8002 || pasteDialog == IntPtr.Zero)) pasteDialog = hwnd;
  }

  /// Ctrl+Alt+V, then confirms the (invisible) Paste Attributes dialog.
  /// Returns "pasted", or "nodialog" if Premiere never opened one.
  public static string PasteAttributesSilently(int timeoutMs) {
    EnsureWatcher();
    pasteDialog = IntPtr.Zero;
    pasteArmed = true;
    try {
      Press("ctrl+alt+v");
      DateTime until = DateTime.Now.AddMilliseconds(timeoutMs);
      while (pasteDialog == IntPtr.Zero && DateTime.Now < until) Thread.Sleep(5);
      if (pasteDialog == IntPtr.Zero) return "nodialog";
      IntPtr d = pasteDialog;
      Thread.Sleep(35); // let the dialog finish building
      if (GetForegroundWindow() != d) Activate(d);
      Press("enter");
      until = DateTime.Now.AddMilliseconds(timeoutMs);
      while (IsWindow(d) && IsWindowVisible(d) && DateTime.Now < until) Thread.Sleep(5);
      return "pasted";
    } finally {
      pasteArmed = false;
    }
  }

  // ---------------- Keys ----------------
  public static ushort Vk(string key) {
    string k = key.Trim().ToLowerInvariant();
    switch (k) {
      case "ctrl": case "control": return 0x11;
      case "shift": return 0x10;
      case "alt": return 0x12;
      case "win": return 0x5B;
      case "enter": return 0x0D;
      case "esc": case "escape": return 0x1B;
      case "tab": return 0x09;
      case "space": return 0x20;
      case "backspace": return 0x08;
      case "delete": return 0x2E;
      case "insert": return 0x2D;
      case "home": return 0x24; case "end": return 0x23;
      case "pageup": return 0x21; case "pagedown": return 0x22;
      case "up": return 0x26; case "down": return 0x28; case "left": return 0x25; case "right": return 0x27;
      case "`": case "backquote": return 0xC0;
      case ";": return 0xBA; case "=": return 0xBB; case ",": return 0xBC; case "-": return 0xBD;
      case ".": return 0xBE; case "/": return 0xBF; case "[": return 0xDB; case "\\": return 0xDC;
      case "]": return 0xDD; case "'": return 0xDE;
    }
    if (k.Length == 1) {
      char ch = Char.ToUpperInvariant(k[0]);
      if ((ch >= 'A' && ch <= 'Z') || (ch >= '0' && ch <= '9')) return (ushort)ch;
    }
    if (k.StartsWith("f")) { int fn; if (Int32.TryParse(k.Substring(1), out fn) && fn >= 1 && fn <= 24) return (ushort)(0x70 + fn - 1); }
    if (k.StartsWith("num")) { int nn; if (Int32.TryParse(k.Substring(3), out nn) && nn >= 0 && nn <= 9) return (ushort)(0x60 + nn); }
    throw new Exception("Unknown key: " + key);
  }

  static INPUT Key(ushort vk, bool up) {
    INPUT i = new INPUT();
    i.type = 1;
    i.u.ki.wVk = vk;
    i.u.ki.dwFlags = up ? KEYEVENTF_KEYUP : 0;
    if (vk >= 0x21 && vk <= 0x2E) i.u.ki.dwFlags |= KEYEVENTF_EXTENDEDKEY;
    i.u.ki.dwExtraInfo = FX_MARK;
    return i;
  }

  /// Presses a combo such as "ctrl+v" or "shift+3". Releases modifiers the user
  /// may still be holding first, so they don't mix into the shortcut.
  public static void Press(string combo) {
    List<INPUT> list = new List<INPUT>();
    foreach (int vk in new int[] { 0x10, 0x11, 0x12, 0x5B })
      if ((GetAsyncKeyState(vk) & 0x8000) != 0) list.Add(Key((ushort)vk, true));
    string[] parts = combo.Split('+');
    foreach (string part in parts) list.Add(Key(Vk(part), false));
    for (int i = parts.Length - 1; i >= 0; i--) list.Add(Key(Vk(parts[i]), true));
    INPUT[] arr = list.ToArray();
    SendInput((uint)arr.Length, arr, Marshal.SizeOf(typeof(INPUT)));
  }

  // ---------------- Global hotkey (low-level keyboard hook) ----------------
  [StructLayout(LayoutKind.Sequential)] struct KBDLLHOOKSTRUCT { public uint vkCode; public uint scanCode; public uint flags; public uint time; public IntPtr dwExtraInfo; }
  delegate IntPtr HookProc(int code, IntPtr wParam, IntPtr lParam);
  [DllImport("user32.dll", SetLastError=true)] static extern IntPtr SetWindowsHookEx(int id, HookProc proc, IntPtr hMod, uint threadId);
  [DllImport("user32.dll")] static extern bool UnhookWindowsHookEx(IntPtr h);
  [DllImport("user32.dll")] static extern IntPtr CallNextHookEx(IntPtr h, int code, IntPtr w, IntPtr l);
  [DllImport("kernel32.dll", CharSet=CharSet.Unicode)] static extern IntPtr GetModuleHandle(string name);
  [StructLayout(LayoutKind.Sequential)] struct MSG { public IntPtr hwnd; public uint message; public IntPtr wParam; public IntPtr lParam; public uint time; public int x; public int y; }
  [DllImport("user32.dll")] static extern int GetMessage(out MSG msg, IntPtr hwnd, uint min, uint max);

  static HookProc hookProc; // kept alive so the GC doesn't collect it
  static IntPtr hook = IntPtr.Zero;
  static volatile int hkVk = 0;
  static volatile bool hkCtrl, hkShift, hkAlt, hkWin;
  static volatile bool swallowUp = false;

  /// Sets the hotkey, e.g. "ctrl+space". Starts the hook thread on first call.
  public static void SetHotkey(string combo) {
    bool c = false, s = false, a = false, w = false; int vk = 0;
    foreach (string raw in combo.Split('+')) {
      string p = raw.Trim().ToLowerInvariant();
      if (p == "ctrl" || p == "control") c = true;
      else if (p == "shift") s = true;
      else if (p == "alt") a = true;
      else if (p == "win") w = true;
      else vk = Vk(p);
    }
    if (vk == 0) throw new Exception("The hotkey needs a key, not just modifiers.");
    hkCtrl = c; hkShift = s; hkAlt = a; hkWin = w; hkVk = vk;
    if (hook == IntPtr.Zero) {
      Thread t = new Thread(HookThread);
      t.IsBackground = true;
      t.Start();
    }
  }

  static bool Down(int vk) { return (GetAsyncKeyState(vk) & 0x8000) != 0; }

  static void HookThread() {
    hookProc = new HookProc(OnKey);
    hook = SetWindowsHookEx(13, hookProc, GetModuleHandle("user32"), 0);
    if (hook == IntPtr.Zero) { Emit("{\"event\":\"hotkeyError\",\"error\":\"Could not install keyboard hook\"}"); return; }
    Emit("{\"event\":\"hotkeyReady\"}");
    MSG msg;
    while (GetMessage(out msg, IntPtr.Zero, 0, 0) > 0) {}
  }

  static IntPtr OnKey(int code, IntPtr wParam, IntPtr lParam) {
    if (code >= 0) {
      KBDLLHOOKSTRUCT k = (KBDLLHOOKSTRUCT)Marshal.PtrToStructure(lParam, typeof(KBDLLHOOKSTRUCT));
      int msg = wParam.ToInt32();
      bool isDown = msg == 0x100 || msg == 0x104;
      bool isUp = msg == 0x101 || msg == 0x105;
      if (k.dwExtraInfo != FX_MARK && (int)k.vkCode == hkVk) {
        if (isDown) {
          bool ctrl = Down(0x11), shift = Down(0x10), alt = Down(0x12), win = Down(0x5B) || Down(0x5C);
          if (ctrl == hkCtrl && shift == hkShift && alt == hkAlt && win == hkWin && PremiereInFront()) {
            swallowUp = true;
            ThreadPool.QueueUserWorkItem(delegate { Emit("{\"event\":\"hotkey\"}"); });
            return new IntPtr(1);
          }
        } else if (isUp && swallowUp) {
          swallowUp = false;
          return new IntPtr(1);
        }
      }
    }
    return CallNextHookEx(hook, code, wParam, lParam);
  }
}
"@

Add-Type -TypeDefinition $source -Language CSharp

function Write-Json($obj) {
  [FxNative]::Emit(($obj | ConvertTo-Json -Compress -Depth 5))
}

# Puts raw formats on the clipboard: @{ "FormatName" = [byte[]] } (+ optional text).
function Set-RawClipboard($formats, $text) {
  $obj = New-Object System.Windows.Forms.DataObject
  foreach ($name in $formats.Keys) {
    $stream = New-Object System.IO.MemoryStream(,[byte[]]$formats[$name])
    $obj.SetData($name, $false, $stream)
  }
  if ($text) { $obj.SetData([System.Windows.Forms.DataFormats]::UnicodeText, $text) }
  [System.Windows.Forms.Clipboard]::SetDataObject($obj, $true, 10, 50)
}

# Saves the image on the clipboard as PNG. Prefers the "PNG" format (keeps
# transparency, used by browsers), then a copied image file, then a bitmap.
function Save-ClipboardImage($file) {
  $dir = Split-Path $file -Parent
  New-Item -ItemType Directory -Path $dir -Force | Out-Null
  $data = [System.Windows.Forms.Clipboard]::GetDataObject()
  if ($null -eq $data) { throw "The clipboard is empty." }

  if ($data.GetDataPresent("PNG")) {
    $png = $data.GetData("PNG")
    if ($png -is [System.IO.MemoryStream]) { [System.IO.File]::WriteAllBytes($file, $png.ToArray()); return $file }
  }
  if ($data.GetDataPresent([System.Windows.Forms.DataFormats]::FileDrop)) {
    foreach ($f in $data.GetData([System.Windows.Forms.DataFormats]::FileDrop)) {
      if ($f -match '\.(png|jpe?g|gif|bmp|webp|tiff?)$') {
        $img = [System.Drawing.Image]::FromFile($f)
        try { $img.Save($file, [System.Drawing.Imaging.ImageFormat]::Png) } finally { $img.Dispose() }
        return $file
      }
    }
  }
  if ([System.Windows.Forms.Clipboard]::ContainsImage()) {
    $img = [System.Windows.Forms.Clipboard]::GetImage()
    try { $img.Save($file, [System.Drawing.Imaging.ImageFormat]::Png) } finally { $img.Dispose() }
    return $file
  }
  throw "There's no image on the clipboard. Right-click an image and choose Copy image first."
}

function Show-Palette($a) {
  $hasPos = ($null -ne $a.x) -and ($null -ne $a.y)
  $x = 0; $y = 0
  if ($hasPos) { $x = [int]$a.x; $y = [int]$a.y }
  $center = 48
  if ($a.barCenter) { $center = [int]$a.barCenter }
  return [FxNative]::PaletteShow([string]$a.title, [int]$a.width, [int]$a.height, $x, $y, $hasPos, $center)
}

function Invoke-Op($cmd) {
  $a = $cmd.args
  switch ($cmd.op) {
    "ping"          { return @{ ok = $true; premiere = ([FxNative]::PremiereWindow() -ne [IntPtr]::Zero) } }
    "setHotkey"     { [FxNative]::SetHotkey([string]$a.combo); return @{ ok = $true } }
    "paletteShow"   { return @{ ok = $true; result = (Show-Palette $a) } }
    "paletteToggle" {
      if ([FxNative]::IsShownAndFront([string]$a.title)) { [FxNative]::PaletteHide([string]$a.title) | Out-Null; return @{ ok = $true; result = "hidden" } }
      return @{ ok = $true; result = (Show-Palette $a) }
    }
    "paletteDrag"   {
      $pos = [FxNative]::PaletteDrag([string]$a.title)
      if (-not $pos) { return @{ ok = $false; error = "Palette window not found" } }
      $xy = $pos.Split(",")
      return @{ ok = $true; x = [int]$xy[0]; y = [int]$xy[1] }
    }
    "pasteAttributes" { return @{ ok = $true; result = [FxNative]::PasteAttributesSilently(1500) } }
    "paletteResize" { return @{ ok = [FxNative]::PaletteResize([string]$a.title, [int]$a.height) } }
    "paletteHide"   { return @{ ok = [FxNative]::PaletteHide([string]$a.title) } }
    "focusWindow"   { return @{ ok = [FxNative]::FocusWindow([string]$a.title); foreground = [FxNative]::ForegroundInfo() } }
    "focusPremiere" { return @{ ok = [FxNative]::FocusPremiere(); foreground = [FxNative]::ForegroundInfo() } }
    "foreground"    { return @{ ok = $true; foreground = [FxNative]::ForegroundInfo(); premiereInFront = [FxNative]::PremiereInFront() } }
    "keys" {
      $gap = 60
      if ($a.gapMs) { $gap = [int]$a.gapMs }
      foreach ($combo in $a.combos) { [FxNative]::Press([string]$combo); Start-Sleep -Milliseconds $gap }
      return @{ ok = $true }
    }
    "dumpClipboard" { return @{ ok = $true; summary = [FxNative]::DumpClipboard([string]$a.dir); dir = $a.dir } }
    "readFormat" {
      $data = [System.Windows.Forms.Clipboard]::GetData([string]$a.format)
      if ($null -eq $data) { return @{ ok = $false; error = "Format not on clipboard: $($a.format)" } }
      $ms = New-Object System.IO.MemoryStream
      $data.CopyTo($ms)
      return @{ ok = $true; base64 = [Convert]::ToBase64String($ms.ToArray()) }
    }
    "setClipboard" {
      $formats = @{}
      foreach ($p in $a.formats.PSObject.Properties) { $formats[$p.Name] = [Convert]::FromBase64String($p.Value) }
      Set-RawClipboard $formats $a.text
      return @{ ok = $true }
    }
    "getText" {
      $t = ""
      if ([System.Windows.Forms.Clipboard]::ContainsText()) { $t = [System.Windows.Forms.Clipboard]::GetText() }
      return @{ ok = $true; text = $t }
    }
    "setText" {
      if ($a.text) { [System.Windows.Forms.Clipboard]::SetText([string]$a.text) } else { [System.Windows.Forms.Clipboard]::Clear() }
      return @{ ok = $true }
    }
    "saveClipboardImage" { return @{ ok = $true; file = (Save-ClipboardImage ([string]$a.file)) } }
    default { return @{ ok = $false; error = "Unknown op: $($cmd.op)" } }
  }
}

if ($DumpClipboard) {
  Write-Host ([FxNative]::DumpClipboard($Out))
  Write-Host "Saved to $Out"
  exit 0
}

if ($Serve) {
  Write-Json @{ event = "ready" }
  while ($true) {
    $line = [Console]::In.ReadLine()
    if ($null -eq $line) { break }
    if (-not $line.Trim()) { continue }
    $id = $null
    try {
      $cmd = $line | ConvertFrom-Json
      $id = $cmd.id
      $reply = Invoke-Op $cmd
    } catch {
      $reply = @{ ok = $false; error = $_.Exception.Message }
    }
    $reply.id = $id
    Write-Json $reply
  }
  exit 0
}

Write-Host "Usage: fxportal-helper.ps1 -Serve | -DumpClipboard [-Out folder]"
