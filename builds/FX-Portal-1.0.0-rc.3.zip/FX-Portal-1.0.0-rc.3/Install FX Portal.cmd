@echo off
rem Double-click to install FX Portal. Close Premiere Pro first.
powershell -NoProfile -ExecutionPolicy Bypass -File "%~dp0install.ps1"
pause
