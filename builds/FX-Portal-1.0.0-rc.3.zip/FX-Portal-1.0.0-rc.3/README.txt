FX Portal 1.0.0 (rc.3)

INSTALL
  1. Close Premiere Pro.
  2. Double-click 'Install FX Portal.cmd'.
  3. Open Premiere Pro, wait a few seconds, press Ctrl+Space.

SETTINGS
  Window > Extensions > FX Portal Settings

UPDATE
  Download the new version and run the installer again. Your settings stay.

REMOVE
  Double-click 'Uninstall FX Portal.cmd'.
