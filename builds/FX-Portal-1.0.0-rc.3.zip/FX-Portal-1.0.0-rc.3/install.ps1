<#
  FX Portal installer (Windows) — run via "Install FX Portal.cmd".
  Installs the FX Portal panel that sits next to this script (folder "fx-portal"
  or a FX-Portal-*.zxp) into Premiere's extensions folder. No admin rights needed.
#>
$ErrorActionPreference = "Stop"
Write-Host ""
Write-Host "  FX Portal installer" -ForegroundColor White
Write-Host "  -------------------"
Write-Host ""

if (Get-Process | Where-Object { $_.ProcessName -like "*Premiere*" }) {
  Write-Host "  Please close Premiere Pro first, then run this again." -ForegroundColor Yellow
  exit 1
}

$extDir = Join-Path $env:APPDATA "Adobe\CEP\extensions"
$target = Join-Path $extDir "com.fxportal"
New-Item -ItemType Directory -Path $extDir -Force | Out-Null

# Remove an older developer link (same panel ID would clash).
$devLink = Join-Path $extDir "fx-portal"
if (Test-Path $devLink) {
  $item = Get-Item $devLink -Force
  if ($item.LinkType) { $item.Delete(); Write-Host "  Removed the developer link (fx-portal)." }
  else { Remove-Item $devLink -Recurse -Force; Write-Host "  Removed an old copy (fx-portal)." }
}

if (Test-Path $target) { Remove-Item $target -Recurse -Force }

$folder = Join-Path $PSScriptRoot "fx-portal"
$zxp = Get-ChildItem -Path $PSScriptRoot -Filter "FX-Portal-*.zxp" -ErrorAction SilentlyContinue | Sort-Object LastWriteTime -Descending | Select-Object -First 1

if (Test-Path (Join-Path $folder "CSXS\manifest.xml")) {
  Copy-Item $folder $target -Recurse -Force
  # The beta isn't code-signed yet, so Premiere needs permission to load it.
  foreach ($v in 10, 11, 12, 13) {
    $key = "HKCU:\Software\Adobe\CSXS.$v"
    if (-not (Test-Path $key)) { New-Item -Path $key -Force | Out-Null }
    Set-ItemProperty -Path $key -Name "PlayerDebugMode" -Value "1" -Type String
  }
} elseif ($zxp) {
  New-Item -ItemType Directory -Path $target -Force | Out-Null
  Add-Type -AssemblyName System.IO.Compression.FileSystem
  [System.IO.Compression.ZipFile]::ExtractToDirectory($zxp.FullName, $target)
} else {
  throw "Couldn't find the FX Portal files next to this installer. Unzip the whole download first."
}

$manifest = Get-Content (Join-Path $target "CSXS\manifest.xml") -Raw
$version = [regex]::Match($manifest, 'ExtensionBundleVersion="([^"]+)"').Groups[1].Value
Write-Host "  Installed FX Portal $version" -ForegroundColor Green
Write-Host ""
Write-Host "  Open Premiere Pro, wait a few seconds, then press Ctrl+Space."
Write-Host "  Settings: Window > Extensions > FX Portal Settings"
Write-Host ""
