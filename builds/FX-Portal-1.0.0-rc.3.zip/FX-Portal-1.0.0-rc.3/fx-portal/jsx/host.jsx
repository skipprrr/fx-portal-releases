/*
 * FX Portal — ExtendScript host (runs inside Premiere).
 * ExtendScript is ES3: no let/const, arrow functions, or guaranteed JSON.
 * Every public fxp_* function returns a JSON string { ok, ... }.
 */

var FXP = FXP || {};
var TICKS = 254016000000; // Premiere ticks per second

// ---------------------------------------------------------------- JSON
FXP.str = function (s) {
  s = String(s);
  var out = '"';
  for (var i = 0; i < s.length; i++) {
    var c = s.charAt(i), code = s.charCodeAt(i);
    if (c === '"' || c === "\\") out += "\\" + c;
    else if (c === "\n") out += "\\n";
    else if (c === "\r") out += "\\r";
    else if (c === "\t") out += "\\t";
    else if (code < 32) out += "\\u" + ("0000" + code.toString(16)).slice(-4);
    else out += c;
  }
  return out + '"';
};
FXP.json = function (v) {
  if (v === null || v === undefined) return "null";
  var t = typeof v;
  if (t === "string") return FXP.str(v);
  if (t === "number") return isFinite(v) ? String(v) : "null";
  if (t === "boolean") return v ? "true" : "false";
  if (v instanceof Array) {
    var a = [];
    for (var i = 0; i < v.length; i++) a.push(FXP.json(v[i]));
    return "[" + a.join(",") + "]";
  }
  var parts = [];
  for (var k in v) if (v.hasOwnProperty(k)) parts.push(FXP.str(k) + ":" + FXP.json(v[k]));
  return "{" + parts.join(",") + "}";
};
FXP.ok = function (data) {
  var o = { ok: true };
  if (data) for (var k in data) if (data.hasOwnProperty(k)) o[k] = data[k];
  return FXP.json(o);
};
FXP.fail = function (msg) {
  return FXP.json({ ok: false, error: String(msg && msg.message ? msg.message : msg) });
};

// ---------------------------------------------------------------- basics
FXP.qe = function () {
  if (typeof qe === "undefined" || !qe) app.enableQE();
  return qe;
};
FXP.names = function (list) {
  var out = [];
  if (!list) return out;
  for (var i = 0; i < list.length; i++) out.push(String(list[i]));
  return out;
};
FXP.seq = function () {
  var seq = app.project ? app.project.activeSequence : null;
  if (!seq) throw new Error("Open a sequence first.");
  return seq;
};
FXP.frameSeconds = function (seq) {
  var tb = Number(seq.timebase);
  return tb > 0 ? tb / TICKS : 1 / 25;
};

/** Selected clips of one media type: [{ track, start, end, clip }]. */
FXP.selected = function (seq, audio) {
  var tracks = audio ? seq.audioTracks : seq.videoTracks;
  var out = [];
  for (var t = 0; t < tracks.numTracks; t++) {
    var clips = tracks[t].clips;
    for (var c = 0; c < clips.numItems; c++) {
      var clip = clips[c];
      var sel = false;
      try { sel = clip.isSelected(); } catch (e) {}
      if (sel) out.push({ track: t, start: String(clip.start.ticks), end: String(clip.end.ticks), clip: clip });
    }
  }
  return out;
};

/** The QE twin of a DOM clip: same track, same start time. */
FXP.qeClip = function (qeSeq, info, audio) {
  var track = audio ? qeSeq.getAudioTrackAt(info.track) : qeSeq.getVideoTrackAt(info.track);
  if (!track) return null;
  for (var i = 0; i < track.numItems; i++) {
    var item = null;
    try { item = track.getItemAt(i); } catch (e) {}
    if (item && String(item.type) === "Clip" && item.start && String(item.start.ticks) === info.start) return item;
  }
  return null;
};

// ---------------------------------------------------------------- info
function fxp_ping() {
  return FXP.ok({ app: String(app.version), project: app.project ? String(app.project.name) : "" });
}

function fxp_listEffects() {
  try {
    var q = FXP.qe();
    return FXP.ok({
      videoEffects: FXP.names(q.project.getVideoEffectList()),
      audioEffects: FXP.names(q.project.getAudioEffectList()),
      videoTransitions: FXP.names(q.project.getVideoTransitionList()),
      audioTransitions: FXP.names(q.project.getAudioTransitionList())
    });
  } catch (e) {
    return FXP.fail(e);
  }
}

function fxp_selectionInfo() {
  try {
    var seq = app.project ? app.project.activeSequence : null;
    if (!seq) return FXP.ok({ sequence: false, video: 0, audio: 0 });
    return FXP.ok({
      sequence: true,
      name: String(seq.name),
      video: FXP.selected(seq, false).length,
      audio: FXP.selected(seq, true).length
    });
  } catch (e) {
    return FXP.fail(e);
  }
}

/** Folder of the open project (for saving pasted images), or "" if unsaved. */
function fxp_projectDir() {
  try {
    var p = app.project && app.project.path ? String(app.project.path) : "";
    if (!p) return FXP.ok({ dir: "" });
    var f = new File(p);
    return FXP.ok({ dir: f.parent ? f.parent.fsName : "", name: String(app.project.name) });
  } catch (e) {
    return FXP.fail(e);
  }
}

// ---------------------------------------------------------------- effects
function fxp_applyEffect(name, audio) {
  try {
    audio = audio === true || audio === "true";
    var seq = FXP.seq();
    var q = FXP.qe();
    var qeSeq = q.project.getActiveSequence();
    var fx = audio ? q.project.getAudioEffectByName(name) : q.project.getVideoEffectByName(name);
    if (!fx) return FXP.fail("Premiere couldn't find the effect \"" + name + "\".");
    var targets = FXP.selected(seq, audio);
    if (!targets.length) return FXP.fail("Select at least one " + (audio ? "audio" : "video") + " clip.");
    var applied = 0;
    for (var i = 0; i < targets.length; i++) {
      var item = FXP.qeClip(qeSeq, targets[i], audio);
      if (!item) continue;
      try {
        var r = audio ? item.addAudioEffect(fx) : item.addVideoEffect(fx);
        if (r !== false) applied++;
      } catch (e) {}
    }
    return FXP.ok({ applied: applied, total: targets.length });
  } catch (e) {
    return FXP.fail(e);
  }
}

// ---------------------------------------------------------------- transitions
FXP.countTransitions = function (seq, audio) {
  var tracks = audio ? seq.audioTracks : seq.videoTracks, n = 0;
  for (var t = 0; t < tracks.numTracks; t++) {
    try { n += tracks[t].transitions.numItems; } catch (e) {}
  }
  return n;
};

/**
 * Adds a transition at the edit points of every selected clip.
 * A cut shared by two selected clips gets one transition, not two.
 * alignment: "center" (on the cut), "start" (starts at cut), "end" (ends at cut).
 */
function fxp_applyTransition(name, audio, seconds, alignment) {
  try {
    audio = audio === true || audio === "true";
    var seq = FXP.seq();
    var q = FXP.qe();
    var qeSeq = q.project.getActiveSequence();
    var tr = audio ? q.project.getAudioTransitionByName(name) : q.project.getVideoTransitionByName(name);
    if (!tr) return FXP.fail("Premiere couldn't find the transition \"" + name + "\".");
    var targets = FXP.selected(seq, audio);
    if (!targets.length) return FXP.fail("Select the clips whose cuts should get \"" + name + "\".");

    var frames = Math.max(1, Math.round(Number(seconds || 0.5) / FXP.frameSeconds(seq)));
    var align = alignment === "start" ? 0 : alignment === "end" ? 1 : -1;

    // Which selected clips end exactly where another selected clip starts (same track)?
    var endsAt = {};
    for (var i = 0; i < targets.length; i++) endsAt[targets[i].track + ":" + targets[i].end] = true;

    var before = FXP.countTransitions(seq, audio);
    var attempts = 0;
    for (var j = 0; j < targets.length; j++) {
      var info = targets[j];
      var item = FXP.qeClip(qeSeq, info, audio);
      if (!item) continue;
      var edges = [false]; // end edge always
      if (!endsAt[info.track + ":" + info.start]) edges.push(true); // start edge unless shared
      for (var k = 0; k < edges.length; k++) {
        try {
          if (align < 0) item.addTransition(tr, edges[k], String(frames));
          else item.addTransition(tr, edges[k], String(frames), "0", align);
          attempts++;
        } catch (e) {}
        // Refetch: adding a transition can invalidate the QE handle.
        item = FXP.qeClip(qeSeq, info, audio) || item;
      }
    }
    var added = FXP.countTransitions(seq, audio) - before;
    return FXP.ok({ added: added >= 0 ? added : attempts, attempts: attempts, frames: frames });
  } catch (e) {
    return FXP.fail(e);
  }
}

// ---------------------------------------------------------------- files
FXP.normPath = function (p) {
  return String(p).replace(/\\/g, "/").toLowerCase();
};

/** Finds or creates a bin by path, e.g. "SFX" or "Audio/SFX". Empty = "FX Portal". */
FXP.binByPath = function (binPath) {
  var parts = String(binPath || "FX Portal").replace(/\\/g, "/").split("/");
  var bin = app.project.rootItem;
  for (var p = 0; p < parts.length; p++) {
    var name = parts[p].replace(/^\s+|\s+$/g, "");
    if (!name) continue;
    var next = null;
    for (var i = 0; i < bin.children.numItems; i++) {
      var c = bin.children[i];
      if (c && c.type === ProjectItemType.BIN && String(c.name) === name) { next = c; break; }
    }
    bin = next || bin.createBin(name);
  }
  return bin === app.project.rootItem ? FXP.binByPath("FX Portal") : bin;
};

FXP.findByName = function (bin, name) {
  for (var i = 0; i < bin.children.numItems; i++) {
    var c = bin.children[i];
    if (c && c.type !== ProjectItemType.BIN && String(c.name) === name) return c;
  }
  return null;
};

FXP.findInBin = function (bin, file) {
  var want = FXP.normPath(file);
  for (var i = 0; i < bin.children.numItems; i++) {
    var c = bin.children[i];
    try {
      if (c && c.type !== ProjectItemType.BIN && FXP.normPath(c.getMediaPath()) === want) return c;
    } catch (e) {}
  }
  return null;
};

/** Imports a file into its bin once, then reuses it. */
FXP.importOnce = function (file, binPath) {
  var bin = FXP.binByPath(binPath);
  var item = FXP.findInBin(bin, file);
  if (item) return item;
  app.project.importFiles([file], true, bin, false);
  item = FXP.findInBin(bin, file);
  if (!item) throw new Error("Premiere couldn't import " + file);
  return item;
};

FXP.durationOf = function (item) {
  try {
    var d = item.getOutPoint().seconds - item.getInPoint().seconds;
    if (d > 0) return d;
  } catch (e) {}
  return 5;
};

FXP.trackFree = function (track, from, to) {
  for (var i = 0; i < track.clips.numItems; i++) {
    var c = track.clips[i];
    if (c.start.seconds < to - 0.0001 && c.end.seconds > from + 0.0001) return false;
  }
  return true;
};

/** Index of the first track free over [from, to]. Video prefers V2 and up. */
FXP.freeTrack = function (seq, audio, from, to) {
  var tracks = audio ? seq.audioTracks : seq.videoTracks;
  var order = [];
  if (audio) for (var a = 0; a < tracks.numTracks; a++) order.push(a);
  else {
    for (var v = 1; v < tracks.numTracks; v++) order.push(v);
    order.push(0);
  }
  for (var i = 0; i < order.length; i++) {
    var t = tracks[order[i]];
    if (t && !t.isLocked() && FXP.trackFree(t, from, to)) return order[i];
  }
  return audio ? 0 : tracks.numTracks - 1;
};

FXP.clipCountAt = function (track, seconds) {
  var n = 0;
  for (var i = 0; i < track.clips.numItems; i++) {
    if (Math.abs(track.clips[i].start.seconds - seconds) < 0.001) n++;
  }
  return n;
};

/** Seconds as "1.25" for subclip names. */
FXP.secs = function (v) {
  return String(Math.round(v * 100) / 100);
};

/**
 * A subclip covering inSec..outSec of a project item (reused if it already exists).
 * Lets a chosen part of a sound go to the timeline without touching the original.
 */
FXP.subclip = function (item, bin, inSec, outSec) {
  var name = String(item.name).replace(/\.[^.]+$/, "") + " (" + FXP.secs(inSec) + "-" + FXP.secs(outSec) + "s)";
  var existing = FXP.findByName(bin, name);
  if (existing) return existing;
  var t0 = String(Math.round(inSec * TICKS)), t1 = String(Math.round(outSec * TICKS));
  var sub = item.createSubClip(name, t0, t1, 0, 1, 1);
  if (!sub) sub = FXP.findByName(item.getBin ? item.getBin() : bin, name) || FXP.findByName(bin, name);
  if (!sub) throw new Error("Premiere couldn't make the trimmed part.");
  return sub;
};

/**
 * Places a file at the playhead on a free track.
 * type: "audio" | "video" | "image" | "mogrt"; binPath: where it's imported;
 * inSec/outSec (optional): only that part of the file.
 */
function fxp_insertFile(file, type, binPath, inSec, outSec) {
  try {
    var seq = FXP.seq();
    var pos = seq.getPlayerPosition();
    var at = pos.seconds;

    if (type === "mogrt") {
      var vIdx = FXP.freeTrack(seq, false, at, at + 5);
      var aIdx = FXP.freeTrack(seq, true, at, at + 5);
      var mgt = seq.importMGT(file, String(pos.ticks), vIdx, aIdx);
      if (!mgt) return FXP.fail("Premiere couldn't add that template.");
      return FXP.ok({ track: (vIdx + 1), kind: "V" });
    }

    var item = FXP.importOnce(file, binPath);
    inSec = Number(inSec); outSec = Number(outSec);
    if (inSec >= 0 && outSec > inSec + 0.01) item = FXP.subclip(item, FXP.binByPath(binPath), inSec, outSec);
    var audio = type === "audio";
    var dur = FXP.durationOf(item);
    var idx = FXP.freeTrack(seq, audio, at, at + dur);
    var track = audio ? seq.audioTracks[idx] : seq.videoTracks[idx];
    var before = FXP.clipCountAt(track, at);

    // The DOM accepts a Time object; fall back to seconds or ticks on older builds.
    var tries = [pos, at, String(pos.ticks)];
    for (var i = 0; i < tries.length; i++) {
      try { track.overwriteClip(item, tries[i]); } catch (e) {}
      if (FXP.clipCountAt(track, at) > before) return FXP.ok({ track: idx + 1, kind: audio ? "A" : "V" });
    }
    return FXP.fail("Couldn't place the file on the timeline.");
  } catch (e) {
    return FXP.fail(e);
  }
}

// ---------------------------------------------------------------- presets
// Preset apply pastes attributes from a carrier clip whose length matches the
// target, so clips are pasted in groups of equal length.

/** Full path of the open project ("" if unsaved). */
function fxp_projectPath() {
  try {
    return FXP.ok({ path: app.project && app.project.path ? String(app.project.path) : "" });
  } catch (e) {
    return FXP.fail(e);
  }
}

/** Selected clips: [{ key, ticks }] where key = "v|a:track:startTicks". */
function fxp_selectedClips(audio) {
  try {
    audio = audio === true || audio === "true";
    var seq = FXP.seq();
    var list = FXP.selected(seq, audio);
    var out = [];
    for (var i = 0; i < list.length; i++) {
      var d = Number(list[i].end) - Number(list[i].start);
      out.push({ key: (audio ? "a:" : "v:") + list[i].track + ":" + list[i].start, ticks: String(Math.round(d)) });
    }
    return FXP.ok({ clips: out, sequenceID: String(seq.sequenceID) });
  } catch (e) {
    return FXP.fail(e);
  }
}

/** Select exactly these clips (keys from fxp_selectedClips), deselect the rest. */
function fxp_selectOnly(keysCsv) {
  try {
    var seq = FXP.seq();
    var want = {};
    var keys = String(keysCsv).split(",");
    for (var k = 0; k < keys.length; k++) if (keys[k]) want[keys[k]] = true;
    var n = 0;
    var groups = [["v:", seq.videoTracks], ["a:", seq.audioTracks]];
    for (var g = 0; g < groups.length; g++) {
      var tracks = groups[g][1];
      for (var t = 0; t < tracks.numTracks; t++) {
        var clips = tracks[t].clips;
        for (var c = 0; c < clips.numItems; c++) {
          var clip = clips[c];
          var key = groups[g][0] + t + ":" + String(clip.start.ticks);
          var on = !!want[key];
          try {
            if (clip.isSelected() !== on) clip.setSelected(on, true);
          } catch (e) {}
          if (on) n++;
        }
      }
    }
    return FXP.ok({ selected: n });
  } catch (e) {
    return FXP.fail(e);
  }
}

/** Make sure this sequence is the active one (Shift+3 can switch timeline tabs). */
function fxp_ensureSequence(sequenceID) {
  try {
    var seq = app.project.activeSequence;
    if (seq && String(seq.sequenceID) === String(sequenceID)) return FXP.ok({ switched: false });
    app.project.openSequence(String(sequenceID));
    return FXP.ok({ switched: true });
  } catch (e) {
    return FXP.fail(e);
  }
}

// ---------------------------------------------------------------- clip effects
/** Effects on the single selected video clip: { key, name, effects: [{ name, matchName, nth }] }. */
function fxp_clipEffects() {
  try {
    var seq = FXP.seq();
    var sel = FXP.selected(seq, false);
    if (sel.length !== 1) return FXP.ok({ key: "", count: sel.length, effects: [] });
    var clip = sel[0].clip;
    var list = [], seen = {};
    for (var i = 0; i < clip.components.numItems; i++) {
      var c = clip.components[i];
      var mn = String(c.matchName), dn = String(c.displayName);
      var nth = seen[mn] || 0;
      seen[mn] = nth + 1;
      list.push({ name: dn, matchName: mn, nth: nth });
    }
    return FXP.ok({ key: "v:" + sel[0].track + ":" + sel[0].start, name: String(clip.name), effects: list });
  } catch (e) {
    return FXP.fail(e);
  }
}
