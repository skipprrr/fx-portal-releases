@echo off
rem Double-click to remove FX Portal from Premiere Pro.
powershell -NoProfile -ExecutionPolicy Bypass -Command "$t = Join-Path $env:APPDATA 'Adobe\CEP\extensions\com.fxportal'; if (Get-Process | Where-Object { $_.ProcessName -like '*Premiere*' }) { Write-Host 'Close Premiere Pro first.' -ForegroundColor Yellow } elseif (Test-Path $t) { Remove-Item $t -Recurse -Force; Write-Host 'FX Portal removed. Your settings are kept in %APPDATA%\FX Portal.' -ForegroundColor Green } else { Write-Host 'FX Portal is not installed.' }"
pause
